param(
    [Parameter(Mandatory = $true)]
    [string]$MachineCode,

    [string]$PrivateKeyPath = "D:\Github\cdsoft-ezacc\.local-secrets\EzAccLicense.private.xml",

    [string]$ProductCode = "CDSOFT_EZACC",

    [string]$LicenseType = "PerMachine",

    [datetime]$IssuedAtUtc
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Convert-ToBase64Url([byte[]]$Bytes) {
    return [Convert]::ToBase64String($Bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_')
}

if ([string]::IsNullOrWhiteSpace($MachineCode)) {
    throw "MachineCode không được để trống."
}

if (-not (Test-Path $PrivateKeyPath)) {
    throw "Không tìm thấy private key tại: $PrivateKeyPath"
}

if (-not $PSBoundParameters.ContainsKey('IssuedAtUtc')) {
    $IssuedAtUtc = [datetime]::UtcNow
}

$normalizedMachineCode = ($MachineCode -replace "-", "").Trim().ToUpperInvariant()
$payload = "product=$ProductCode;machine=$normalizedMachineCode;license=$LicenseType;issued=$($IssuedAtUtc.ToString('o'))"
$payloadBytes = [System.Text.Encoding]::UTF8.GetBytes($payload)

$privateXml = Get-Content -Path $PrivateKeyPath -Raw
$rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider 2048
$rsa.PersistKeyInCsp = $false
$rsa.FromXmlString($privateXml)
$signatureBytes = $rsa.SignData($payloadBytes, [System.Security.Cryptography.SHA256CryptoServiceProvider]::new())

$activationKey = "EZACC1|" + (Convert-ToBase64Url $payloadBytes) + "|" + (Convert-ToBase64Url $signatureBytes)

Write-Output ""
Write-Output "MachineCode : $MachineCode"
Write-Output "Issued UTC  : $($IssuedAtUtc.ToString('o'))"
Write-Output ""
Write-Output "ActiveKey:"
Write-Output $activationKey
